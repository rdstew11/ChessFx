
public class Rook extends Piece {

	public Rook(String team) {
		super(team);
		loadImage("Rook");
	}

}

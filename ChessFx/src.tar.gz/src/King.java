
public class King extends Piece{
	
	public King(String team) {
		super(team);
		loadImage("King");
	}
}

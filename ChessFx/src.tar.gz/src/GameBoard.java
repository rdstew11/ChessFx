import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;

public class GameBoard extends GridPane{
	private Tile[][] tiles;
	
	public GameBoard(int nRows, int nCols) {
		tiles = new Tile[nRows][nCols];
		for(int col = 0; col < nCols; col++) {
			for(int row = 0; row < nRows; row++) {
				Tile tile = new Tile(); 
				this.add(tile, col, row);
				
				if((col + row) % 2 == 0) {
					tile.setFill(Color.WHITE);
				}
				else {
					tile.setFill(Color.web("#7393B3"));
				}
				tiles[row][col] = tile;
			}
		}
		this.setBorder(ChessApp.SOLID_BLACK_BORDER);
	}
	
	public Tile getTile(int row, int col) {
		return tiles[row][col];
	}
	
}

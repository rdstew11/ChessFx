package fxml;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class PlayerClient {
	public PlayerClient(String serverIp, int port, ChessController chessController, BoardModel boardModel) throws Throwable {
		System.out.format("Connecting to server at %s on port %d%n", serverIp, port);
		Socket socket = new Socket(serverIp, port);
		System.out.println("Connected to server");
		
		ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
		ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
		
		Object msg = in.readObject();
		if(msg instanceof PlayerRegistration) {
			int playerId = ((PlayerRegistration) msg).playerId;
		}
	}
}

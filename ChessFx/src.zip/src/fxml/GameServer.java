package fxml;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class GameServer {
	protected static final int PORT = 7777;
	private static final int MAX_CLIENTS = 2;
	
	public GameServer() throws Throwable{
		ServerSocket server;
		Socket client;
		server = new ServerSocket(PORT);
		ArrayList<PlayerHandler> clients = new ArrayList<PlayerHandler>();
		
		while(clients.size() < MAX_CLIENTS) {
			System.out.println("Server listening on port: "  + PORT);
			client = server.accept();
			System.out.println("Client detected");
			if (clients.size() == MAX_CLIENTS) {
				System.out.println("Reached max clients - unable to connect");
				client.close();
			}
			else {
				clients.add(new PlayerHandler(client, clients.size()));
			}
		}
		
	}
	
	public static void main(String[] args) throws Throwable {
		new GameServer();
	}
}

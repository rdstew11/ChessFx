package fxml;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class PlayerHandler {
	private Socket socket;
	private int playerId;
	
	public PlayerHandler(Socket socket, int playerId) throws Throwable {
		this.socket = socket;
		this.playerId = playerId;
		System.out.println("Starting handler for id: " + playerId);
		ObjectInputStream in = new ObjectInputStream(this.socket.getInputStream());
		ObjectOutputStream out = new ObjectOutputStream(this.socket.getOutputStream());
	}
}

package fxml;

public class PlayerRegistration {
	protected int playerId;
	
	public PlayerRegistration(int playerId) {
		this.playerId = playerId;
	}
}

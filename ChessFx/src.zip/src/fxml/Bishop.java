package fxml;

public class Bishop extends Piece {

	public Bishop(String team) {
		super(team);
		loadImage("Bishop");
	}

}

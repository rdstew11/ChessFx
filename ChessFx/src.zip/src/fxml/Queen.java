package fxml;
public class Queen extends Piece{

	public Queen (String team) {
		super(team);
		loadImage("Queen");
	}
}

package fxml;

public class Knight extends Piece {

	public Knight(String team) {
		super(team);
		loadImage("Knight");
	}

}

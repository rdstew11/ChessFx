
public class Pawn extends Piece {
	public Pawn(String team) {
		super(team);
		loadImage("Pawn");
	}
}
